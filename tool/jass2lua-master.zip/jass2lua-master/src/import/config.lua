require 'scripts.utility'
require 'scripts.native'
require 'scripts.common'
require 'scripts.blizzard'
require 'scripts.war3map'

config()
