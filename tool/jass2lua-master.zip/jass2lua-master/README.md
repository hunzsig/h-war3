jass2lua
========
可以将一张魔兽地图的核心脚本由jass转化为lua.转化后的地图可以在JAPI环境下游玩.



使用
----
将地图拖动到"make.bat"上,等待转换完成即可。


JAPI环境
----
目前支持的环境有两个,两个环境的基本一致。

1. [YDWE](https://github.com/actboy168/YDWE)
2. [11对战平台](http://www.5211game.com/)


编译
----
一般情况下不需要编译，如果你需要重新编译[build目录](build)下二进制文件，可以在[YDWE](https://github.com/actboy168/YDWE)找到相关的工程。
