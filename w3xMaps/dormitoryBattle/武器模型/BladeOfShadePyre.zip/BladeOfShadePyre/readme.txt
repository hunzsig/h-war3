Blade of ShadePyre
By Thrikodius

Description:
Just an idea I got. For those who wonder, ShadePyre is a demon that I will make later. In the mean time I suggest you enjoy his blade and the other weapons that are about to come. Fore when ShadePyre arrives you will all... [HIDDEN=&quot;threat&quot;]BE COVERED WITH FEATHERS[/HIDDEN]

Give credits if you use.

Textures:
Fire4x2.blp

Please give me credit for my work
Do not redistribute this model without consent!

Model was uploaded 2009, May 19
Model was last updated 2009, June 3


Visit http://www.hiveworkshop.com for more downloads